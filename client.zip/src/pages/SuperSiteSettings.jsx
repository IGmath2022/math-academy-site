// client/src/pages/SuperSiteSettings.jsx
import SuperSettings from "./SuperSettings";
export default SuperSettings;
