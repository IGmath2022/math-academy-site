// client/src/pages/StaffDashboard.js
import React from "react";
import StaffTabs from "../components/Staff/StaffTabs";

export default function StaffDashboard() {
  return <StaffTabs />;
}
